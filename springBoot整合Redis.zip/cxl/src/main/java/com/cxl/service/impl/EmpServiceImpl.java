package com.cxl.service.impl;

import com.cxl.entity.Emp;
import com.cxl.mapper.EmpMapper;
import com.cxl.service.IEmpService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author itcast
 * @since 2023-05-11
 */
@Service
public class EmpServiceImpl extends ServiceImpl<EmpMapper, Emp> implements IEmpService {

    @Resource
    private EmpMapper empMapper;

    @Resource
    private RedisTemplate redisTemplate;


    @Override
    //添加用户
    public void add(Emp emp) {
        empMapper.insert(emp);
    }

    @Override
    //根据Id查询用户
    public Object getEmpById(Integer id) {
        //先从缓存里获取数据 如果有数据则直接返回
        //如果没有 就查询数据库 并将数据存到缓存

        String key = "user:" + id;
        Object userObj = redisTemplate.opsForValue().get(key);
        if (userObj == null) {
            //同步代码块
            synchronized (this.getClass()) {
                userObj = redisTemplate.opsForValue().get(key);
                if (userObj == null) {
                    System.out.println("进入数据库..............");
                    //说明在缓存里面没有这个数据 查询数据库 存入缓存
                    Emp emp = empMapper.selectById(id);
                    redisTemplate.opsForValue().set(key, emp);
                    return emp;
                }else{
                    System.out.println("进入缓存(同步代码块)..............");
                }

            }

        } else {
            System.out.println("进入缓存..............");
        }


        return userObj;
    }
}
