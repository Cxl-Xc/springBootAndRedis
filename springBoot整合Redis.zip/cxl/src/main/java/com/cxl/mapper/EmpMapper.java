package com.cxl.mapper;

import com.cxl.entity.Emp;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author itcast
 * @since 2023-05-11
 */
public interface EmpMapper extends BaseMapper<Emp> {

}
