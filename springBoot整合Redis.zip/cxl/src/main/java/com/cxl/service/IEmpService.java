package com.cxl.service;

import com.cxl.entity.Emp;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author itcast
 * @since 2023-05-11
 */
public interface IEmpService extends IService<Emp> {
    //添加用户
    public void add(Emp emp);
    //根据id查询用户
    public Object getEmpById(Integer id);

}
