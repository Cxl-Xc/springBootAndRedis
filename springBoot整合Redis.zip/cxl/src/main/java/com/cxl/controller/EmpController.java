package com.cxl.controller;


import com.cxl.entity.Emp;
import com.cxl.service.IEmpService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.stereotype.Controller;

import javax.annotation.Resource;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author itcast
 * @since 2023-05-11
 */
@RestController
@CrossOrigin
@RequiredArgsConstructor
public class EmpController {

    @Resource
    private IEmpService iEmpService;

    //添加用户
    @PostMapping("/addEmp")
    public String addEmp(Emp emp) {

        iEmpService.add(emp);
        return "add ok";

    }

    //根据Id查询用户
    @GetMapping("/getEmpById")
    public Object getEmpById(@RequestParam Integer id) {

        //模拟高并发
        ExecutorService es = Executors.newFixedThreadPool(200);
        for (int i = 0; i < 500; i++) {
            es.submit(new Runnable() {
                @Override
                public void run() {
                    iEmpService.getEmpById(id);
                }
            });
        }



        return iEmpService.getEmpById(id);

    }





}
